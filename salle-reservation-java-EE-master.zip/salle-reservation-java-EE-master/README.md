# salle-reservation-java-EE-
application that manage salle reservation for university .
required : 
          glassfish server -> EJB 3;
          java 8;
          MSQL database;-
frameworks:
          JSF;
          JPA/eclipselink;

netbeans  8.1

