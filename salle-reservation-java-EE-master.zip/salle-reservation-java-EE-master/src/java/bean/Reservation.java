/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;

/**
 *
 * @author kamal
 */
@Entity
public class Reservation implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date startDate;
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date endDate;
    private String description;
    private String color;
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date periodiciteDateDebut;
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date periodiciteDateFin;
    private String periodiciteDays;
    private ReservationType type;
    @ManyToOne
    private Module module = new Module();
    @ManyToMany
    private List<Salle> salle = new ArrayList<>();

    public enum ReservationType {

        CC, TD, COURS, TP
    }

    public String getPeriodiciteDays() {
        return periodiciteDays;
    }

    public void setPeriodiciteDays(String periodiciteDays) {
        this.periodiciteDays = periodiciteDays;
    }

  

    public Date getPeriodiciteDateDebut() {
        return periodiciteDateDebut;
    }

    public void setPeriodiciteDateDebut(Date periodiciteDateDebut) {
        this.periodiciteDateDebut = periodiciteDateDebut;
    }

    public Date getPeriodiciteDateFin() {
        return periodiciteDateFin;
    }

    public void setPeriodiciteDateFin(Date periodiciteDateFin) {
        this.periodiciteDateFin = periodiciteDateFin;
    }

    public Date getStartDate() {
        return startDate;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ReservationType getType() {
        return type;
    }

    public void setType(ReservationType StrType) {
        this.type = StrType;
    }

    public Module getModule() {
        return module;
    }

    public void setModule(Module module) {
        this.module = module;
    }

    public List<Salle> getSalle() {
        return salle;
    }

    public void setSalle(List<Salle> salle) {
        this.salle = salle;
    }

    public Reservation() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Reservation)) {
            return false;
        }
        Reservation other = (Reservation) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "bean.Reservation[ id=" + id + " ]";
    }

}
